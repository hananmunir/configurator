import React from 'react'

function ServicesComponent() {
  return (
    <div style={{
        width: "70%",
        height: "30px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        border: "2px solid #fae20e",
        borderRadius: "30px",
        color: "white",
        fontSize: "14px",
        transform: "translateX(45px)",
    }}>ServicesComponent</div>
  )
}

export default ServicesComponent